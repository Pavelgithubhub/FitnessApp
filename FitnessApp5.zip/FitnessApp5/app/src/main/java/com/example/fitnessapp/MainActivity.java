package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView backImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        backImageView = findViewById(R.id.backImageView);
        Random random = new Random();
        int randomImageNumber = 1 + random.nextInt(5);
        switch (randomImageNumber){
            case 1: backImageView.setImageResource(R.drawable.fon_1); break;
            case 2: backImageView.setImageResource(R.drawable.fon_2); break;
            case 3: backImageView.setImageResource(R.drawable.fon_3); break;
            case 4: backImageView.setImageResource(R.drawable.fon_4); break;
            case 5: backImageView.setImageResource(R.drawable.fon_5); break;
        }

    }
}